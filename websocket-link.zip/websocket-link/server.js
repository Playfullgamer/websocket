const WebSocket = require("ws");

const wss = new WebSocket.Server({ port: 8080 });

wss.on("connection", (ws) => {
  ws.send("connected");

  ws.on("message", (msg) => {
    ws.send(msg.toString());
  });
});

console.log("WebSocket running at ws://localhost:8080");
